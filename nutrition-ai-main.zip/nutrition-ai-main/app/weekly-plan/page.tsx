"use client"

import { DashboardNavbar } from "@/components/dashboard-navbar"
import { WeeklySummary } from "@/components/weekly-summary"
import { WeeklyGrid } from "@/components/weekly-grid"

export default function WeeklyPlanPage() {
  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <main className="pt-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground">Weekly Plan</h1>
            <p className="text-muted-foreground mt-2">
              Your nutrition overview for the week with daily targets and achievements
            </p>
          </div>
          <div className="space-y-8">
            <WeeklySummary />
            <WeeklyGrid />
          </div>
        </div>
      </main>
    </div>
  )
}
