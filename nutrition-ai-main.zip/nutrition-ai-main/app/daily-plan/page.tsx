"use client"

import { DashboardNavbar } from "@/components/dashboard-navbar"
import { DailyMealPlan } from "@/components/daily-meal-plan"
import { DailyTotals } from "@/components/daily-totals"
import { useSearchParams } from "next/navigation"

export default function DailyPlanPage() {
  const searchParams = useSearchParams()
  const date = searchParams.get("date") || new Date().toISOString().split("T")[0]

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <main className="pt-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground">Plan for {formatDate(date)}</h1>
            <p className="text-muted-foreground mt-2">
              Detailed meal plan with nutrition breakdown and tracking options
            </p>
          </div>
          <div className="space-y-8">
            <DailyMealPlan />
            <DailyTotals />
          </div>
        </div>
      </main>
    </div>
  )
}
