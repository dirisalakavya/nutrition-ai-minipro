"use client"

import { DashboardNavbar } from "@/components/dashboard-navbar"
import { MonthlySummary } from "@/components/monthly-summary"
import { MonthlyCalendar } from "@/components/monthly-calendar"

export default function MonthlyPlanPage() {
  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <main className="pt-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground">Monthly Plan</h1>
            <p className="text-muted-foreground mt-2">
              Track your monthly progress and identify patterns in your nutrition journey
            </p>
          </div>
          <div className="space-y-8">
            <MonthlySummary />
            <MonthlyCalendar />
          </div>
        </div>
      </main>
    </div>
  )
}
