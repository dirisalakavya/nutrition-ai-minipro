"use client"

import { DashboardNavbar } from "@/components/dashboard-navbar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DailyReport } from "@/components/daily-report"
import { WeeklyReport } from "@/components/weekly-report"
import { MonthlyReport } from "@/components/monthly-report"
import { ComparisonReport } from "@/components/comparison-report"

export default function ReportsPage() {
  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Nutrition Reports</h1>
          <p className="text-muted-foreground">Comprehensive analytics and progress tracking</p>
        </div>

        <Tabs defaultValue="daily" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="daily">Daily Report</TabsTrigger>
            <TabsTrigger value="weekly">Weekly Report</TabsTrigger>
            <TabsTrigger value="monthly">Monthly Report</TabsTrigger>
            <TabsTrigger value="comparison">Before vs After</TabsTrigger>
          </TabsList>

          <TabsContent value="daily">
            <DailyReport />
          </TabsContent>

          <TabsContent value="weekly">
            <WeeklyReport />
          </TabsContent>

          <TabsContent value="monthly">
            <MonthlyReport />
          </TabsContent>

          <TabsContent value="comparison">
            <ComparisonReport />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
