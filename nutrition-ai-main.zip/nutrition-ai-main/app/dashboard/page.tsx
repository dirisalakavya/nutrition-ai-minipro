"use client"

import { DashboardNavbar } from "@/components/dashboard-navbar"
import { NutritionSummary } from "@/components/nutrition-summary"
import { MealSuggestions } from "@/components/meal-suggestions"

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <main className="pt-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground">Daily Nutrition Summary</h1>
            <p className="text-muted-foreground mt-2">
              Track your progress and stay on target with your nutrition goals
            </p>
          </div>
          <div className="space-y-8">
            <NutritionSummary />
            <MealSuggestions />
          </div>
        </div>
      </main>
    </div>
  )
}
