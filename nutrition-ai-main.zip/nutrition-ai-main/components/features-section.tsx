import { Card, CardContent } from "@/components/ui/card"
import { Apple, BarChart3, Zap, Bell } from "lucide-react"

const features = [
  {
    icon: Apple,
    title: "Personalized Plans",
    description: "AI tailors meals to your body and goals, creating nutrition plans that work specifically for you.",
  },
  {
    icon: BarChart3,
    title: "Track Progress",
    description: "Visual dashboards for calories, macros, and weight trends to keep you motivated and on track.",
  },
  {
    icon: Zap,
    title: "Smart Suggestions",
    description: "Swap meals instantly, get healthier alternatives, and discover new recipes that fit your lifestyle.",
  },
  {
    icon: Bell,
    title: "Stay Motivated",
    description: "Achievements, reminders, and real-time feedback to help you maintain healthy eating habits.",
  },
]

export function FeaturesSection() {
  return (
    <section id="features" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold mb-6 text-balance">
            Everything you need for <span className="text-primary">smart nutrition</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Our AI-powered platform provides comprehensive tools to transform your relationship with food and achieve
            your health goals.
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="bg-card/50 border-border/50 hover:bg-card/80 transition-all duration-300 group"
            >
              <CardContent className="p-8">
                <div className="mb-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center group-hover:bg-primary/20 transition-colors duration-300">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-4 text-balance">{feature.title}</h3>
                <p className="text-muted-foreground text-pretty leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
