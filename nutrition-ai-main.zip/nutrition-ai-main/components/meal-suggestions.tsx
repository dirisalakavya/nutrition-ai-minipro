"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Check, RefreshCw } from "lucide-react"
import { useState } from "react"

const mealSuggestions = [
  {
    type: "Breakfast",
    name: "Greek Yogurt Bowl",
    calories: 320,
    protein: 18,
    carbs: 35,
    fat: 8,
    description: "Greek yogurt with berries, granola, and honey",
  },
  {
    type: "Lunch",
    name: "Grilled Chicken Salad",
    calories: 450,
    protein: 35,
    carbs: 25,
    fat: 18,
    description: "Mixed greens with grilled chicken, avocado, and vinaigrette",
  },
  {
    type: "Dinner",
    name: "Salmon with Quinoa",
    calories: 520,
    protein: 40,
    carbs: 45,
    fat: 22,
    description: "Baked salmon with quinoa and roasted vegetables",
  },
  {
    type: "Snack",
    name: "Apple with Almond Butter",
    calories: 180,
    protein: 6,
    carbs: 20,
    fat: 12,
    description: "Sliced apple with 2 tbsp natural almond butter",
  },
]

export function MealSuggestions() {
  const [acceptedMeals, setAcceptedMeals] = useState<number[]>([])

  const handleAccept = (index: number) => {
    setAcceptedMeals((prev) => [...prev, index])
  }

  const handleSwap = (index: number) => {
    // Remove from accepted if it was accepted
    setAcceptedMeals((prev) => prev.filter((i) => i !== index))
    // In a real app, this would fetch a new meal suggestion
    alert(`Swapping ${mealSuggestions[index].name} for a new suggestion!`)
  }

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Today's Suggested Meals</h2>
      <div className="grid md:grid-cols-2 gap-6">
        {mealSuggestions.map((meal, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow duration-200">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{meal.type}</span>
                <span className="text-sm font-normal text-muted-foreground">{meal.calories} cal</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-lg">{meal.name}</h3>
                  <p className="text-muted-foreground text-sm">{meal.description}</p>
                </div>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Protein</span>
                    <p className="font-medium">{meal.protein}g</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Carbs</span>
                    <p className="font-medium">{meal.carbs}g</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Fat</span>
                    <p className="font-medium">{meal.fat}g</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className="flex-1"
                    onClick={() => handleAccept(index)}
                    disabled={acceptedMeals.includes(index)}
                  >
                    <Check className="w-4 h-4 mr-2" />
                    {acceptedMeals.includes(index) ? "Accepted" : "Accept"}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 bg-transparent"
                    onClick={() => handleSwap(index)}
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Swap
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
