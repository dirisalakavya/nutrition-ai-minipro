import { Card, CardContent } from "@/components/ui/card"
import { User, Brain, TrendingUp } from "lucide-react"

const steps = [
  {
    icon: User,
    step: "01",
    title: "Enter your details",
    description: "Tell us about your age, weight, goals, dietary preferences, and lifestyle to get started.",
  },
  {
    icon: Brain,
    step: "02",
    title: "Get your personalized meal plan",
    description: "Our AI analyzes your information and creates a custom nutrition plan instantly tailored to you.",
  },
  {
    icon: TrendingUp,
    step: "03",
    title: "Track progress and refine",
    description:
      "Monitor your results, get insights, and let our AI continuously optimize your plan for better outcomes.",
  },
]

export function HowItWorksSection() {
  return (
    <section id="how-it-works" className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold mb-6 text-balance">How it works</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Get started with personalized nutrition in three simple steps. Our AI does the heavy lifting so you can
            focus on your health.
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <Card
              key={index}
              className="bg-background/50 border-border/50 relative overflow-hidden group hover:bg-background/80 transition-all duration-300"
            >
              <CardContent className="p-8">
                <div className="mb-6">
                  <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center group-hover:bg-primary/20 transition-colors duration-300 mb-4">
                    <step.icon className="w-8 h-8 text-primary" />
                  </div>
                  <div className="text-6xl font-bold text-primary/20 absolute top-4 right-6">{step.step}</div>
                </div>
                <h3 className="text-2xl font-semibold mb-4 text-balance">{step.title}</h3>
                <p className="text-muted-foreground text-pretty leading-relaxed">{step.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
