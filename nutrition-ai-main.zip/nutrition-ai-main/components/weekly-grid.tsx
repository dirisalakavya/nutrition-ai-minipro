import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

const weeklyPlan = [
  {
    day: "Monday",
    date: "Dec 16",
    calories: 1900,
    highlight: "Protein-rich day",
    status: "completed",
  },
  {
    day: "Tuesday",
    date: "Dec 17",
    calories: 2100,
    highlight: "Balanced nutrition",
    status: "completed",
  },
  {
    day: "Wednesday",
    date: "Dec 18",
    calories: 1850,
    highlight: "Light day",
    status: "completed",
  },
  {
    day: "Thursday",
    date: "Dec 19",
    calories: 2050,
    highlight: "High fiber focus",
    status: "completed",
  },
  {
    day: "Friday",
    date: "Dec 20",
    calories: 1950,
    highlight: "Omega-3 rich",
    status: "completed",
  },
  {
    day: "Saturday",
    date: "Dec 21",
    calories: 2200,
    highlight: "Cheat day allowed",
    status: "current",
  },
  {
    day: "Sunday",
    date: "Dec 22",
    calories: 1800,
    highlight: "Low-carb day",
    status: "upcoming",
  },
]

export function WeeklyGrid() {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-primary/10 text-primary"
      case "current":
        return "bg-accent/10 text-accent-foreground"
      case "upcoming":
        return "bg-muted text-muted-foreground"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">7-Day Plan</h2>
        <Link href="/daily-plan">
          <Button>View Daily Plan</Button>
        </Link>
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {weeklyPlan.map((day, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow duration-200">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{day.day}</CardTitle>
                <Badge variant="secondary" className={getStatusColor(day.status)}>
                  {day.status}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground">{day.date}</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Calories</span>
                  <span className="font-semibold">{day.calories}</span>
                </div>
                <div className="p-3 bg-muted/50 rounded-lg">
                  <p className="text-sm font-medium text-center">{day.highlight}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
