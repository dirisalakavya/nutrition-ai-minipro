"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { useRouter } from "next/navigation"

export function DashboardNavbar() {
  const router = useRouter()

  const handleLogout = () => {
    router.push("/")
  }

  return (
    <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <span className="text-2xl font-bold text-primary">NutritionAI</span>
            </div>
            <div className="hidden md:block ml-10">
              <div className="flex items-baseline space-x-8">
                <Link href="/dashboard" className="text-foreground hover:text-primary transition-colors duration-200">
                  Dashboard
                </Link>
                <Link
                  href="/weekly-plan"
                  className="text-muted-foreground hover:text-primary transition-colors duration-200"
                >
                  Weekly Plan
                </Link>
                <Link
                  href="/monthly-plan"
                  className="text-muted-foreground hover:text-primary transition-colors duration-200"
                >
                  Monthly Plan
                </Link>
                <Link
                  href="/daily-plan"
                  className="text-muted-foreground hover:text-primary transition-colors duration-200"
                >
                  Daily Plan
                </Link>
                <Link
                  href="/reports"
                  className="text-muted-foreground hover:text-primary transition-colors duration-200"
                >
                  Reports
                </Link>
                <Link
                  href="/profile"
                  className="text-muted-foreground hover:text-primary transition-colors duration-200"
                >
                  Profile
                </Link>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </div>
    </nav>
  )
}
