"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  BarChart,
  Bar,
  AreaChart,
  Area,
} from "recharts"

const monthlyData = [
  { week: "Week 1", avgCalories: 1920, avgWeight: 70.5, exerciseDays: 6, proteinGoal: 85 },
  { week: "Week 2", avgCalories: 1880, avgWeight: 70.2, exerciseDays: 5, proteinGoal: 88 },
  { week: "Week 3", avgCalories: 1950, avgWeight: 69.8, exerciseDays: 7, proteinGoal: 92 },
  { week: "Week 4", avgCalories: 1931, avgWeight: 69.7, exerciseDays: 7, proteinGoal: 95 },
]

const monthlyMacros = [
  { nutrient: "Protein", week1: 105, week2: 110, week3: 115, week4: 113 },
  { nutrient: "Carbs", week1: 165, week2: 160, week3: 170, week4: 168 },
  { nutrient: "Fat", week1: 78, week2: 75, week3: 80, week4: 77 },
]

const monthlyStats = [
  { metric: "Total Weight Loss", value: "0.8", unit: "kg", change: "+0.3kg from last month" },
  { metric: "Avg Daily Calories", value: "1920", unit: "kcal", change: "-50 kcal from last month" },
  { metric: "Exercise Sessions", value: "25", unit: "days", change: "+5 days from last month" },
  { metric: "Goal Achievement", value: "92", unit: "%", change: "+8% from last month" },
]

export function MonthlyReport() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {monthlyStats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">{stat.metric}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">
                {stat.value}
                {stat.unit}
              </div>
              <p className="text-xs text-muted-foreground">{stat.change}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Weight Progress</CardTitle>
            <CardDescription>Monthly weight loss trend</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                avgWeight: { label: "Weight (kg)", color: "#10b981" },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="week" />
                  <YAxis domain={["dataMin - 0.5", "dataMax + 0.5"]} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line type="monotone" dataKey="avgWeight" stroke="var(--color-avgWeight)" strokeWidth={3} />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Weekly Calorie Average</CardTitle>
            <CardDescription>Average daily calories per week</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                avgCalories: { label: "Avg Calories", color: "hsl(var(--primary))" },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="week" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="avgCalories" fill="var(--color-avgCalories)" />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Exercise Consistency</CardTitle>
            <CardDescription>Exercise days per week throughout the month</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                exerciseDays: { label: "Exercise Days", color: "#8b5cf6" },
                goal: { label: "Goal (5 days)", color: "#ef4444" },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="week" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Area
                    type="monotone"
                    dataKey="exerciseDays"
                    stroke="var(--color-exerciseDays)"
                    fill="var(--color-exerciseDays)"
                    fillOpacity={0.6}
                  />
                  <Line dataKey={5} stroke="var(--color-goal)" strokeDasharray="5 5" />
                </AreaChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Protein Goal Achievement</CardTitle>
            <CardDescription>Weekly protein goal achievement percentage</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                proteinGoal: { label: "Protein Goal %", color: "#10b981" },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="week" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line type="monotone" dataKey="proteinGoal" stroke="var(--color-proteinGoal)" strokeWidth={3} />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
