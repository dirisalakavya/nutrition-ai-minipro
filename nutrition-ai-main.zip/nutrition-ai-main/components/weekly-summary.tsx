"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts"

const weeklyData = [
  { day: "Mon", calories: 1900, goal: 2000 },
  { day: "Tue", calories: 2100, goal: 2000 },
  { day: "Wed", calories: 1850, goal: 2000 },
  { day: "Thu", calories: 2050, goal: 2000 },
  { day: "Fri", calories: 1950, goal: 2000 },
  { day: "Sat", calories: 2200, goal: 2000 },
  { day: "Sun", calories: 1800, goal: 2000 },
]

export function WeeklySummary() {
  const averageCalories = Math.round(weeklyData.reduce((sum, day) => sum + day.calories, 0) / weeklyData.length)
  const daysOnTarget = weeklyData.filter((day) => Math.abs(day.calories - day.goal) <= 100).length

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Weekly Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Average Calories</span>
              <span className="font-semibold">{averageCalories}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Days on Target</span>
              <span className="font-semibold">{daysOnTarget}/7</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Weekly Goal</span>
              <span className="font-semibold">2000 cal/day</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Calories vs Goal</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={weeklyData}>
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="calories" fill="hsl(var(--primary))" />
              <Bar dataKey="goal" fill="hsl(var(--muted))" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  )
}
