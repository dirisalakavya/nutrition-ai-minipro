"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
} from "recharts"

const weeklyData = [
  { day: "Mon", calories: 1850, protein: 105, carbs: 165, fat: 75, weight: 70.2, exercise: 60 },
  { day: "Tue", calories: 1920, protein: 115, carbs: 170, fat: 78, weight: 70.1, exercise: 45 },
  { day: "Wed", calories: 1780, protein: 98, carbs: 155, fat: 72, weight: 70.0, exercise: 30 },
  { day: "Thu", calories: 2050, protein: 125, carbs: 180, fat: 85, weight: 69.9, exercise: 75 },
  { day: "Fri", calories: 1890, protein: 110, carbs: 168, fat: 76, weight: 69.8, exercise: 50 },
  { day: "Sat", calories: 2200, protein: 130, carbs: 195, fat: 92, weight: 69.9, exercise: 90 },
  { day: "Sun", calories: 1830, protein: 108, carbs: 170, fat: 77, weight: 69.7, exercise: 45 },
]

const weeklyGoals = [
  { metric: "Avg Calories", actual: 1931, goal: 2000, unit: "kcal" },
  { metric: "Avg Protein", actual: 113, goal: 120, unit: "g" },
  { metric: "Exercise Days", actual: 7, goal: 5, unit: "days" },
  { metric: "Weight Loss", actual: 0.5, goal: 0.3, unit: "kg" },
]

export function WeeklyReport() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {weeklyGoals.map((goal, index) => (
          <Card key={index}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">{goal.metric}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">
                {goal.actual}
                {goal.unit}
              </div>
              <p className="text-xs text-muted-foreground">
                Goal: {goal.goal}
                {goal.unit} ({Math.round((goal.actual / goal.goal) * 100)}%)
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Daily Calories</CardTitle>
            <CardDescription>Calorie intake vs goal throughout the week</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                calories: { label: "Calories", color: "hsl(var(--primary))" },
                goal: { label: "Goal", color: "#ef4444" },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="calories" fill="var(--color-calories)" />
                  <Line dataKey={2000} stroke="var(--color-goal)" strokeDasharray="5 5" />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Weight Progress</CardTitle>
            <CardDescription>Daily weight tracking and trend</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                weight: { label: "Weight (kg)", color: "#10b981" },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis domain={["dataMin - 0.2", "dataMax + 0.2"]} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line type="monotone" dataKey="weight" stroke="var(--color-weight)" strokeWidth={3} />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Macronutrient Trends</CardTitle>
            <CardDescription>Daily protein, carbs, and fat intake</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                protein: { label: "Protein", color: "#10b981" },
                carbs: { label: "Carbs", color: "#3b82f6" },
                fat: { label: "Fat", color: "#f59e0b" },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Area
                    type="monotone"
                    dataKey="protein"
                    stackId="1"
                    stroke="var(--color-protein)"
                    fill="var(--color-protein)"
                    fillOpacity={0.6}
                  />
                  <Area
                    type="monotone"
                    dataKey="carbs"
                    stackId="1"
                    stroke="var(--color-carbs)"
                    fill="var(--color-carbs)"
                    fillOpacity={0.6}
                  />
                  <Area
                    type="monotone"
                    dataKey="fat"
                    stackId="1"
                    stroke="var(--color-fat)"
                    fill="var(--color-fat)"
                    fillOpacity={0.6}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Exercise Activity</CardTitle>
            <CardDescription>Daily exercise duration in minutes</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                exercise: { label: "Exercise (min)", color: "#8b5cf6" },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="exercise" fill="var(--color-exercise)" />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
