"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"

// Generate calendar data for December 2024
const generateCalendarData = () => {
  const days = []
  const daysInMonth = 31
  const startDay = 0 // Sunday (December 1, 2024 starts on Sunday)

  // Add empty cells for days before the month starts
  for (let i = 0; i < startDay; i++) {
    days.push(null)
  }

  // Add days of the month
  for (let day = 1; day <= daysInMonth; day++) {
    const caloriesGoal = 2000
    const caloriesAchieved = Math.floor(Math.random() * 600) + 1600 // Random between 1600-2200
    const percentage = Math.min((caloriesAchieved / caloriesGoal) * 100, 100)

    let status = "red"
    if (percentage >= 90) status = "green"
    else if (percentage >= 70) status = "yellow"

    days.push({
      day,
      caloriesGoal,
      caloriesAchieved,
      percentage,
      status,
    })
  }

  return days
}

const calendarData = generateCalendarData()
const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

export function MonthlyCalendar() {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "green":
        return "bg-primary/20 border-primary/50"
      case "yellow":
        return "bg-accent/20 border-accent/50"
      case "red":
        return "bg-destructive/20 border-destructive/50"
      default:
        return "bg-muted border-border"
    }
  }

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">December 2024</h2>
      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-7 gap-2 mb-4">
            {dayNames.map((dayName) => (
              <div key={dayName} className="text-center text-sm font-medium text-muted-foreground p-2">
                {dayName}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-2">
            {calendarData.map((dayData, index) => (
              <div key={index} className="aspect-square">
                {dayData ? (
                  <Link href={`/daily-plan?date=2024-12-${dayData.day.toString().padStart(2, "0")}`}>
                    <Card
                      className={`h-full cursor-pointer hover:shadow-md transition-shadow ${getStatusColor(dayData.status)}`}
                    >
                      <CardContent className="p-2 h-full flex flex-col justify-between">
                        <div className="text-sm font-medium">{dayData.day}</div>
                        <div className="space-y-1">
                          <Progress value={dayData.percentage} className="h-1" />
                          <div className="text-xs text-center">{Math.round(dayData.percentage)}%</div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ) : (
                  <div className="h-full"></div>
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-center gap-6 mt-6 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-primary/20 border border-primary/50 rounded"></div>
              <span>Goal Met (90%+)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-accent/20 border border-accent/50 rounded"></div>
              <span>Close (70-89%)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-destructive/20 border border-destructive/50 rounded"></div>
              <span>Missed (&lt;70%)</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
