"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts"

const dailyTotals = {
  calories: { planned: 1550, target: 2000 },
  protein: { planned: 80, target: 120 },
  carbs: { planned: 180, target: 250 },
  fat: { planned: 56, target: 70 },
}

const chartData = [
  { name: "Calories", planned: dailyTotals.calories.planned, target: dailyTotals.calories.target },
  { name: "Protein (g)", planned: dailyTotals.protein.planned, target: dailyTotals.protein.target },
  { name: "Carbs (g)", planned: dailyTotals.carbs.planned, target: dailyTotals.carbs.target },
  { name: "Fat (g)", planned: dailyTotals.fat.planned, target: dailyTotals.fat.target },
]

export function DailyTotals() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Daily Totals vs Target</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-muted/50 rounded">
              <span className="font-medium">Calories</span>
              <span className="text-lg">
                <span className="font-bold">{dailyTotals.calories.planned}</span>
                <span className="text-muted-foreground"> / {dailyTotals.calories.target}</span>
              </span>
            </div>
            <div className="flex justify-between items-center p-3 bg-muted/50 rounded">
              <span className="font-medium">Protein</span>
              <span className="text-lg">
                <span className="font-bold">{dailyTotals.protein.planned}g</span>
                <span className="text-muted-foreground"> / {dailyTotals.protein.target}g</span>
              </span>
            </div>
            <div className="flex justify-between items-center p-3 bg-muted/50 rounded">
              <span className="font-medium">Carbs</span>
              <span className="text-lg">
                <span className="font-bold">{dailyTotals.carbs.planned}g</span>
                <span className="text-muted-foreground"> / {dailyTotals.carbs.target}g</span>
              </span>
            </div>
            <div className="flex justify-between items-center p-3 bg-muted/50 rounded">
              <span className="font-medium">Fat</span>
              <span className="text-lg">
                <span className="font-bold">{dailyTotals.fat.planned}g</span>
                <span className="text-muted-foreground"> / {dailyTotals.fat.target}g</span>
              </span>
            </div>
          </div>

          <div>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="planned" fill="hsl(var(--primary))" name="Planned" />
                <Bar dataKey="target" fill="hsl(var(--muted))" name="Target" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
