"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts"

const weightData = [
  { week: "Week 1", weight: 175 },
  { week: "Week 2", weight: 174 },
  { week: "Week 3", weight: 173 },
  { week: "Week 4", weight: 172 },
]

export function MonthlySummary() {
  return (
    <div className="grid md:grid-cols-3 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Monthly Stats</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Avg Calories</span>
              <span className="font-semibold">1,950</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Days Goal Met</span>
              <span className="font-semibold">85%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Best Streak</span>
              <span className="font-semibold">5 days</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Weight Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={150}>
            <LineChart data={weightData}>
              <XAxis dataKey="week" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="weight" stroke="hsl(var(--primary))" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>This Month</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Weight Lost</span>
              <span className="font-semibold text-primary">-3 lbs</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Workouts</span>
              <span className="font-semibold">18</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Cheat Days</span>
              <span className="font-semibold">4</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
