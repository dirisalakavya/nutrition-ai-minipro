"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  LineChart,
  Line,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts"
import { Badge } from "@/components/ui/badge"

const beforeAfterData = [
  { metric: "Weight", before: 72.5, after: 69.7, unit: "kg", improvement: -2.8 },
  { metric: "Body Fat", before: 22, after: 18, unit: "%", improvement: -4 },
  { metric: "Muscle Mass", before: 45, after: 47, unit: "kg", improvement: 2 },
  { metric: "Daily Calories", before: 2200, after: 1920, unit: "kcal", improvement: -280 },
  { metric: "Exercise Days/Week", before: 2, after: 6, unit: "days", improvement: 4 },
  { metric: "Water Intake", before: 1.5, after: 2.2, unit: "L", improvement: 0.7 },
]

const monthlyComparison = [
  { month: "Month 1", beforePlan: 72.5, afterPlan: 71.8 },
  { month: "Month 2", beforePlan: 71.8, afterPlan: 70.9 },
  { month: "Month 3", beforePlan: 70.9, afterPlan: 69.7 },
]

const habitComparison = [
  { habit: "Meal Planning", before: 20, after: 95 },
  { habit: "Exercise", before: 30, after: 85 },
  { habit: "Water Intake", before: 40, after: 90 },
  { habit: "Sleep Quality", before: 60, after: 80 },
  { habit: "Stress Management", before: 35, after: 75 },
  { habit: "Nutrition Tracking", before: 10, after: 92 },
]

export function ComparisonReport() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {beforeAfterData.map((item, index) => (
          <Card key={index}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">{item.metric}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-2">
                <div>
                  <div className="text-sm text-muted-foreground">
                    Before: {item.before}
                    {item.unit}
                  </div>
                  <div className="text-lg font-bold text-primary">
                    After: {item.after}
                    {item.unit}
                  </div>
                </div>
                <Badge variant={item.improvement > 0 ? "default" : "secondary"} className="ml-2">
                  {item.improvement > 0 ? "+" : ""}
                  {item.improvement}
                  {item.unit}
                </Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Weight Loss Progress</CardTitle>
            <CardDescription>3-month weight loss journey comparison</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                beforePlan: { label: "Before Plan", color: "#ef4444" },
                afterPlan: { label: "After Plan", color: "#10b981" },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyComparison}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis domain={["dataMin - 1", "dataMax + 1"]} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line
                    type="monotone"
                    dataKey="beforePlan"
                    stroke="var(--color-beforePlan)"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                  />
                  <Line type="monotone" dataKey="afterPlan" stroke="var(--color-afterPlan)" strokeWidth={3} />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Before vs After Metrics</CardTitle>
            <CardDescription>Key health metrics comparison</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                before: { label: "Before", color: "#ef4444" },
                after: { label: "After", color: "#10b981" },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={beforeAfterData.slice(0, 4)} layout="horizontal">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="metric" type="category" width={100} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="before" fill="var(--color-before)" />
                  <Bar dataKey="after" fill="var(--color-after)" />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lifestyle Habits Transformation</CardTitle>
          <CardDescription>Before vs after habit scores (0-100)</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              before: { label: "Before", color: "#ef4444" },
              after: { label: "After", color: "#10b981" },
            }}
            className="h-[400px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={habitComparison}>
                <PolarGrid />
                <PolarAngleAxis dataKey="habit" />
                <PolarRadiusAxis angle={90} domain={[0, 100]} />
                <Radar
                  name="Before"
                  dataKey="before"
                  stroke="var(--color-before)"
                  fill="var(--color-before)"
                  fillOpacity={0.3}
                />
                <Radar
                  name="After"
                  dataKey="after"
                  stroke="var(--color-after)"
                  fill="var(--color-after)"
                  fillOpacity={0.3}
                />
                <ChartTooltip />
              </RadarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-green-50 border-green-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-800">Total Weight Loss</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">2.8kg</div>
            <p className="text-xs text-green-700">In 3 months</p>
          </CardContent>
        </Card>
        <Card className="bg-blue-50 border-blue-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-blue-800">Habit Improvement</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">+58%</div>
            <p className="text-xs text-blue-700">Average across all habits</p>
          </CardContent>
        </Card>
        <Card className="bg-purple-50 border-purple-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-purple-800">Goal Achievement</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-600">92%</div>
            <p className="text-xs text-purple-700">Monthly average</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
