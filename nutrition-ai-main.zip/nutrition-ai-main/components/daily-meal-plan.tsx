"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Check, RefreshCw, Plus } from "lucide-react"
import { useState } from "react"

const dailyMeals = [
  {
    type: "Breakfast",
    time: "8:00 AM",
    meal: {
      name: "Overnight Oats with Berries",
      calories: 350,
      protein: 12,
      carbs: 58,
      fat: 8,
      ingredients: [
        "1 cup rolled oats",
        "1 cup almond milk",
        "1/2 cup mixed berries",
        "1 tbsp chia seeds",
        "1 tsp honey",
      ],
    },
  },
  {
    type: "Lunch",
    time: "12:30 PM",
    meal: {
      name: "Mediterranean Quinoa Bowl",
      calories: 480,
      protein: 18,
      carbs: 65,
      fat: 16,
      ingredients: [
        "1 cup cooked quinoa",
        "1/4 cup chickpeas",
        "2 tbsp feta cheese",
        "Mixed vegetables",
        "Olive oil dressing",
      ],
    },
  },
  {
    type: "Snack",
    time: "3:30 PM",
    meal: {
      name: "Greek Yogurt with Nuts",
      calories: 200,
      protein: 15,
      carbs: 12,
      fat: 10,
      ingredients: ["1 cup Greek yogurt", "1 oz mixed nuts", "1 tsp honey"],
    },
  },
  {
    type: "Dinner",
    time: "7:00 PM",
    meal: {
      name: "Grilled Salmon with Sweet Potato",
      calories: 520,
      protein: 35,
      carbs: 45,
      fat: 22,
      ingredients: ["6 oz salmon fillet", "1 medium roasted sweet potato", "Steamed broccoli", "Lemon herb seasoning"],
    },
  },
]

export function DailyMealPlan() {
  const [acceptedMeals, setAcceptedMeals] = useState<number[]>([])
  const [loggedMeals, setLoggedMeals] = useState<number[]>([])

  const handleAccept = (index: number) => {
    setAcceptedMeals((prev) => [...prev, index])
  }

  const handleSwap = (index: number) => {
    setAcceptedMeals((prev) => prev.filter((i) => i !== index))
    alert(`Swapping ${dailyMeals[index].meal.name} for a new suggestion!`)
  }

  const handleLogEaten = (index: number) => {
    setLoggedMeals((prev) => [...prev, index])
    setAcceptedMeals((prev) => [...prev, index])
  }

  return (
    <div className="space-y-6">
      {dailyMeals.map((mealTime, index) => (
        <Card key={index} className="hover:shadow-lg transition-shadow duration-200">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-xl">{mealTime.type}</CardTitle>
                <p className="text-sm text-muted-foreground mt-1">{mealTime.time}</p>
              </div>
              <Badge variant="secondary" className="bg-primary/10 text-primary">
                {mealTime.meal.calories} cal
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-lg mb-2">{mealTime.meal.name}</h3>
                <div className="grid grid-cols-3 gap-4 text-sm mb-4">
                  <div className="text-center p-2 bg-muted/50 rounded">
                    <p className="text-muted-foreground">Protein</p>
                    <p className="font-semibold">{mealTime.meal.protein}g</p>
                  </div>
                  <div className="text-center p-2 bg-muted/50 rounded">
                    <p className="text-muted-foreground">Carbs</p>
                    <p className="font-semibold">{mealTime.meal.carbs}g</p>
                  </div>
                  <div className="text-center p-2 bg-muted/50 rounded">
                    <p className="text-muted-foreground">Fat</p>
                    <p className="font-semibold">{mealTime.meal.fat}g</p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">Ingredients:</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  {mealTime.meal.ingredients.map((ingredient, idx) => (
                    <li key={idx} className="flex items-center">
                      <span className="w-2 h-2 bg-primary/50 rounded-full mr-2"></span>
                      {ingredient}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex gap-2 pt-2">
                <Button
                  size="sm"
                  className="flex-1"
                  onClick={() => handleAccept(index)}
                  disabled={acceptedMeals.includes(index)}
                >
                  <Check className="w-4 h-4 mr-2" />
                  {acceptedMeals.includes(index) ? "Accepted" : "Accept"}
                </Button>
                <Button variant="outline" size="sm" className="flex-1 bg-transparent" onClick={() => handleSwap(index)}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Swap
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="bg-transparent"
                  onClick={() => handleLogEaten(index)}
                  disabled={loggedMeals.includes(index)}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {loggedMeals.includes(index) ? "Logged" : "Log Eaten"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
