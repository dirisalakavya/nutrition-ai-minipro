import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

const nutritionData = {
  calories: { target: 2000, consumed: 850 },
  protein: { target: 120, consumed: 40 },
  carbs: { target: 250, consumed: 100 },
  fat: { target: 70, consumed: 25 },
}

export function NutritionSummary() {
  const getProgressPercentage = (consumed: number, target: number) => {
    return Math.min((consumed / target) * 100, 100)
  }

  const getProgressColor = (percentage: number) => {
    if (percentage >= 80) return "bg-primary"
    if (percentage >= 50) return "bg-accent"
    return "bg-chart-3"
  }

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Calories</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Consumed</span>
              <span className="font-medium">{nutritionData.calories.consumed}</span>
            </div>
            <Progress
              value={getProgressPercentage(nutritionData.calories.consumed, nutritionData.calories.target)}
              className="h-2"
            />
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Target</span>
              <span className="font-medium">{nutritionData.calories.target}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Protein</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Consumed</span>
              <span className="font-medium">{nutritionData.protein.consumed}g</span>
            </div>
            <Progress
              value={getProgressPercentage(nutritionData.protein.consumed, nutritionData.protein.target)}
              className="h-2"
            />
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Target</span>
              <span className="font-medium">{nutritionData.protein.target}g</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Carbs</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Consumed</span>
              <span className="font-medium">{nutritionData.carbs.consumed}g</span>
            </div>
            <Progress
              value={getProgressPercentage(nutritionData.carbs.consumed, nutritionData.carbs.target)}
              className="h-2"
            />
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Target</span>
              <span className="font-medium">{nutritionData.carbs.target}g</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Fat</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Consumed</span>
              <span className="font-medium">{nutritionData.fat.consumed}g</span>
            </div>
            <Progress
              value={getProgressPercentage(nutritionData.fat.consumed, nutritionData.fat.target)}
              className="h-2"
            />
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Target</span>
              <span className="font-medium">{nutritionData.fat.target}g</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
