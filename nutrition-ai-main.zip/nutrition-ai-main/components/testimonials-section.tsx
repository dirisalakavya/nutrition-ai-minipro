import { Card, CardContent } from "@/components/ui/card"
import { Star } from "lucide-react"

const testimonials = [
  {
    name: "Priya",
    quote:
      "This app helped me lose 5kg in 2 months! The AI recommendations were spot-on and actually fit my busy lifestyle.",
    rating: 5,
  },
  {
    name: "Arjun",
    quote:
      "Finally, a diet app that understands my preferences. The meal suggestions are delicious and I never feel restricted.",
    rating: 5,
  },
  {
    name: "Sarah",
    quote:
      "The progress tracking is incredible. Seeing my improvements in real-time keeps me motivated every single day.",
    rating: 5,
  },
]

export function TestimonialsSection() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold mb-6 text-balance">Loved by thousands of users</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Join the community of people who have transformed their health with AI-powered nutrition planning.
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-card/50 border-border/50 hover:bg-card/80 transition-all duration-300">
              <CardContent className="p-8">
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-accent fill-current" />
                  ))}
                </div>
                <blockquote className="text-lg mb-6 text-pretty leading-relaxed">"{testimonial.quote}"</blockquote>
                <div className="font-semibold text-primary">– {testimonial.name}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
