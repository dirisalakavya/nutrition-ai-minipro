"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts"

const dailyNutritionData = [
  { meal: "Breakfast", calories: 420, protein: 25, carbs: 45, fat: 18 },
  { meal: "Lunch", calories: 650, protein: 35, carbs: 55, fat: 28 },
  { meal: "Snack", calories: 180, protein: 8, carbs: 22, fat: 9 },
  { meal: "Dinner", calories: 580, protein: 40, carbs: 48, fat: 22 },
]

const macroDistribution = [
  { name: "Protein", value: 108, color: "#10b981" },
  { name: "Carbs", value: 170, color: "#3b82f6" },
  { name: "Fat", value: 77, color: "#f59e0b" },
]

const hourlyActivity = [
  { hour: "6AM", calories: 0, water: 250 },
  { hour: "8AM", calories: 420, water: 500 },
  { hour: "10AM", calories: 420, water: 750 },
  { hour: "12PM", calories: 1070, water: 1000 },
  { hour: "2PM", calories: 1070, water: 1250 },
  { hour: "4PM", calories: 1250, water: 1500 },
  { hour: "6PM", calories: 1250, water: 1750 },
  { hour: "8PM", calories: 1830, water: 2000 },
]

export function DailyReport() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Calories</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">1,830</div>
            <p className="text-xs text-muted-foreground">Goal: 2,000 (92%)</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Protein</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">108g</div>
            <p className="text-xs text-muted-foreground">Goal: 120g (90%)</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Water Intake</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">2.0L</div>
            <p className="text-xs text-muted-foreground">Goal: 2.5L (80%)</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Exercise</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">45min</div>
            <p className="text-xs text-muted-foreground">Cardio + Strength</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Calories by Meal</CardTitle>
            <CardDescription>Daily calorie distribution across meals</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                calories: { label: "Calories", color: "hsl(var(--primary))" },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dailyNutritionData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="meal" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="calories" fill="var(--color-calories)" />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Macro Distribution</CardTitle>
            <CardDescription>Today's macronutrient breakdown</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                protein: { label: "Protein", color: "#10b981" },
                carbs: { label: "Carbs", color: "#3b82f6" },
                fat: { label: "Fat", color: "#f59e0b" },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={macroDistribution}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    dataKey="value"
                    label={({ name, value }) => `${name}: ${value}g`}
                  >
                    {macroDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <ChartTooltip />
                </PieChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Hourly Activity</CardTitle>
          <CardDescription>Calorie intake and water consumption throughout the day</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              calories: { label: "Calories", color: "hsl(var(--primary))" },
              water: { label: "Water (ml)", color: "#3b82f6" },
            }}
            className="h-[300px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={hourlyActivity}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="hour" />
                <YAxis />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Line type="monotone" dataKey="calories" stroke="var(--color-calories)" strokeWidth={2} />
                <Line type="monotone" dataKey="water" stroke="var(--color-water)" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  )
}
